/*
** Options for the 1-degree Indian Ocean teaching configuration.
** Application flag: IO_1DEG        Input script: roms_io_1deg.in
** All CPP options live in THIS file (build_roms.sh adds none).
*/

/* ---- Momentum ------------------------------------------------------- */
#define UV_ADV            /* advection of momentum                        */
#define UV_COR            /* Coriolis                                     */
#define UV_QDRAG          /* quadratic bottom drag (RDRG2 in .in)         */
#define UV_VIS2           /* Laplacian viscosity (VISC2 in .in)           */
#define MIX_S_UV          /* ...applied along s-surfaces                  */

/* ---- Tracers -------------------------------------------------------- */
#define SALINITY
#define NONLIN_EOS        /* nonlinear equation of state                  */
#define TS_DIF2           /* Laplacian tracer diffusion (TNU2 in .in)     */
#define MIX_GEO_TS        /* ...along geopotential surfaces: avoids       */
                          /* spurious mixing over steep s-coordinates     */
#define SOLAR_SOURCE      /* shortwave penetrates below the surface       */

/* ---- Grid & numerics ------------------------------------------------ */
#define SOLVE3D
#define CURVGRID
#define MASKING
#define DJ_GRADPS         /* pressure-gradient scheme                     */
#define SPLINES_VDIFF
#define SPLINES_VVISC

/* ---- Vertical mixing: KPP ------------------------------------------- */
/* Without a scheme, ROMS only has the tiny background AKT_BAK (5e-6):   */
/* no mixed layer, no convection.                                        */
#define LMD_MIXING
#ifdef LMD_MIXING
# define LMD_RIMIX        /* shear mixing in the interior                 */
# define LMD_CONVEC       /* convection when the column is unstable       */
# define LMD_SKPP         /* surface boundary layer                       */
# define LMD_BKPP         /* bottom boundary layer                        */
# define LMD_NONLOCAL
# define RI_SPLINES
#endif

/* ---- Surface forcing: bulk formulae with ERA5 ----------------------- */
#define BULK_FLUXES
#ifdef BULK_FLUXES
# define LONGWAVE_OUT     /* input = DOWNWARD longwave (ERA5 strd)        */
# define EMINUSP          /* salt flux from evaporation - precipitation   */
#endif

/* ---- Bottom tracer fluxes = 0 --------------------------------------- */
#define ANA_BSFLUX
#define ANA_BTFLUX

/* ---- Output --------------------------------------------------------- */
#define AVERAGES