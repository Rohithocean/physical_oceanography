/*
** git $Id$
*******************************************************************************
** Copyright (c) 2002-2025 The ROMS Group                                    **
**   Licensed under a MIT/X style license                                    **
**   See License_ROMS.md                                                     **
*******************************************************************************
**
** Options for River Plume Test (original version).
**
** Application flag:   RIVERPLUME1
** Input script:       roms_riverplume1.in
*/

#define UV_ADV
#define UV_COR
#define UV_QDRAG
#define DJ_GRADPS
#define SPLINES_VDIFF
#define SPLINES_VVISC
#define NONLIN_EOS
#define SALINITY
#define MASKING
#define SOLVE3D
#define UV_VIS2
#define TS_DIF2
#define UV_VIS4
#define TS_DIF4


#ifdef LMD_MIXING
# define LMD_RIMIX
# define LMD_CONVEC
# define LMD_SKPP
# define LMD_BKPP
# define LMD_NONLOCAL
# define RI_SPLINES
#endif

#undef ANA_GRID
#undef ANA_INITIAL
#undef ANA_PSOURCE
#define SOLAR_SOURCE
#define CURVGRID
#define AVERAGES
#define  AVERAGES_FLUXES

/*#define DIAGNOSTICS_TS*/
#define BULK_FLUXES
#ifdef BULK_FLUXES
#undef LONGWAVE_OUT
#undef LONGWAVE
#define EMINUSP
#endif
#define ANA_BSFLUX
#define ANA_BTFLUX

